package com.cg.trainapp.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.trainapp.bean.TrainBean;
import com.cg.trainapp.exception.TrainException;
import com.cg.trainapp.service.ITrainService;
import com.cg.trainapp.service.TrainServiceImpl;


public class TrainMain {

	static Scanner sc = new Scanner(System.in);
	static ITrainService trainService = null;
	static TrainServiceImpl trainServiceImpl = null;
	static Logger logger = Logger.getRootLogger();
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		TrainBean trainBean = null;

		String ticketId = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   IRCTC MOBILE APP ");
			System.out.println("_______________________________\n");

			System.out.println("1.Book Ticket ");
			System.out.println("2.View Booking");
			System.out.println("3.Retrieve All");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
	
			try {
				option = sc.nextInt();

				switch (option) {

				case 1:
					while (trainBean == null) {
						trainBean = populateTrainBean();
						// System.out.println(donorBean);
					}
					
					try {
						trainService = new TrainServiceImpl();
						ticketId = trainService.addPassengerDetails(trainBean);

						System.out.println("Passenger details has been successfully registered ");
						System.out.println("Your ticket ID Is : " + ticketId);
						System.out.println("Your ticket amount :"+trainBean.getTicketPrice());

					} catch (TrainException trainException) {
						logger.error("exception occured", trainException);
						System.err.println("ERROR : "+ trainException.getMessage());
					} finally {
						ticketId = null;
						trainService = null;
						trainBean = null;
					}

					break;
					
				case 2:
					trainServiceImpl = new TrainServiceImpl();

					System.out.println("Enter numeric ticket id:");
					ticketId = sc.next();

					/*while (true) {
						if (trainServiceImpl.validateTicketId(ticketId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric ticket id only, try again");
							ticketId = sc.next();
						}
					}*/

					trainBean = getBookingDetails(ticketId);

					if (trainBean != null) {
						System.out.println("Name             :"
								+ trainBean.getPassengerName());
						System.out.println("Address          :"
								+ trainBean.getAddress());
						System.out.println("Phone Number     :"
								+ trainBean.getPhoneNumber());
						System.out.println("Booking Date     :"
								+ trainBean.getBookingDate());
						System.out.println("Destination      :"
								+ trainBean.getDestination());
						System.out.println("Ticket Price     :"
								+ trainBean.getTicketPrice());
					} else {
						System.err
								.println("There are no booking details associated with ticket id "
										+ ticketId);
					}

					break;

				case 3:

					trainService = new TrainServiceImpl();
					try {
						List<TrainBean> trainList = new ArrayList<TrainBean>();
						trainList = trainService.retriveAllDetails();

						if (trainList != null) {
							Iterator<TrainBean> i = trainList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("Nobody has booked , yet.");
						}

					}

					catch (TrainException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;
					
					
				case 4:

					System.out.print("Application exit successfull");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");

				}
			}
			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
			
		}
	}

	
	
	
	
	
	private static TrainBean populateTrainBean() {
	// Reading and setting the values for the trainBean
		
		TrainBean trainBean = new TrainBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter passenger name: ");
		trainBean.setPassengerName(sc.next());

		System.out.println("Enter passenger contact: ");
		trainBean.setPhoneNumber(sc.next());

		System.out.println("Enter passenger address: ");
		trainBean.setAddress(sc.next());

		System.out.println("Enter destination: ");
		trainBean.setDestination(sc.next());
		
		trainBean.setTicketPrice(150);
		
		trainServiceImpl = new TrainServiceImpl();

		try {
			trainServiceImpl.validateTrain(trainBean);
			return trainBean;
		} catch (TrainException donorException) {
			logger.error("exception occured", donorException);
			System.err.println("Invalid data:");
			System.err.println(donorException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return trainBean;
	}
	
	private static TrainBean getBookingDetails(String ticketId) {
		TrainBean trainBean = null;
		trainService = new TrainServiceImpl();

		try {
			trainBean = trainService.viewBookingDetails(ticketId);
		} catch (TrainException trainException) {
			logger.error("exception occured ", trainException);
			System.out.println("ERROR : " + trainException.getMessage());
		}

		trainService = null;
		return trainBean;
	}
}
