package com.cg.trainapp.dao;

import java.util.List;

import com.cg.trainapp.bean.TrainBean;
import com.cg.trainapp.exception.TrainException;



public interface ITrainDao {

	public String addPassengerDetails(TrainBean trainBean) throws TrainException;
	public TrainBean viewBookingDetails(String ticketID) throws TrainException;
	public List<TrainBean> retriveAllDetails() throws TrainException;

	

	
}
