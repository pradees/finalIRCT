package com.cg.trainapp.exception;

public class TrainException extends Exception {

	private static final long serialVersionUID = 726264577455921591L;

	public TrainException(String message) 
	{
		
		super(message);
	}
}
